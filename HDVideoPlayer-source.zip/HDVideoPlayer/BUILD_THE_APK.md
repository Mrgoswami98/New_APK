# Getting the APK

Three routes. Pick one. Route A needs nothing installed on your machine.

---

## Route A - let GitHub build it (no local setup)

1. Create a new repository on github.com (private is fine).
2. Upload the contents of this folder to it. The web UI works:
   **Add file > Upload files**, then drag everything in. Make sure the
   hidden `.github` folder goes up too - if the drag-and-drop skips it,
   create `.github/workflows/build-apk.yml` manually with **Create new file**
   and paste the contents from this project.
3. Go to the **Actions** tab. The build starts on its own; if not, pick
   "Build APK" and press **Run workflow**.
4. Wait about 3-5 minutes. Open the finished run, scroll to **Artifacts**,
   and download `hd-video-player-apk`. Unzip it - your APK is inside.
5. Copy it to your phone and install. You will need to allow
   "Install unknown apps" for whichever app you open it with.

This is free on public repos and on the free private-repo minutes allowance.

---

## Route B - Android Studio

1. Install Android Studio, open this folder.
2. Accept the prompt to generate the Gradle wrapper and sync.
3. **Build > Generate App Bundles or APKs > Generate APKs**.
4. APK lands in `app/build/outputs/apk/debug/`.

---

## Route C - command line, if you already have the Android SDK

```bash
cd HDVideoPlayer
gradle wrapper --gradle-version 8.9
./gradlew assembleRelease
```
APK: `app/build/outputs/apk/release/app-release.apk`

---

## About the signature

Release builds are currently signed with the **debug** key so that the build
works with no setup. That APK installs and runs on your phone perfectly well.
Play Store will reject it. For a real release, generate a keystore:

```bash
keytool -genkey -v -keystore release.jks -keyalg RSA \
  -keysize 2048 -validity 10000 -alias hdplayer
```

then add a `signingConfigs.release` block in `app/build.gradle.kts` and point
the release build type at it instead of `signingConfigs.getByName("debug")`.
