// Pass 2 - contrast-adaptive sharpening, then an optional light grade.
//
// A fixed unsharp mask ruins low-quality sources: it amplifies compression
// blocking and mosquito noise as eagerly as it amplifies detail. This instead
// measures local headroom from a 5-tap cross and scales sharpening by how much
// room the neighbourhood has before clipping. Flat/noisy regions get almost
// none; genuine edges get the most. That is what keeps 480p sources watchable
// rather than crunchy.
precision mediump float;

uniform sampler2D uTexSampler;
uniform vec2 uTexelSize;    // 1.0 / output resolution
uniform float uSharpness;   // 0.0 .. 1.0
uniform float uSaturation;  // 1.0 = unchanged
uniform float uContrast;    // 1.0 = unchanged
varying vec2 vTexCoord;

void main() {
  vec2 t = uTexelSize;
  vec3 e = texture2D(uTexSampler, vTexCoord).rgb;

  if (uSharpness <= 0.001) {
    gl_FragColor = vec4(e, 1.0);
    return;
  }

  vec3 b = texture2D(uTexSampler, vTexCoord + vec2(0.0, -t.y)).rgb;
  vec3 d = texture2D(uTexSampler, vTexCoord + vec2(-t.x, 0.0)).rgb;
  vec3 f = texture2D(uTexSampler, vTexCoord + vec2( t.x, 0.0)).rgb;
  vec3 h = texture2D(uTexSampler, vTexCoord + vec2(0.0,  t.y)).rgb;

  vec3 mn = min(min(min(b, d), min(f, h)), e);
  vec3 mx = max(max(max(b, d), max(f, h)), e);

  // Headroom: how far the darkest can fall and the brightest can rise.
  vec3 amp = clamp(min(mn, 1.0 - mx) / max(mx, vec3(1e-5)), 0.0, 1.0);
  amp = sqrt(amp);

  // Negative lobe weight. Stronger sharpness -> smaller divisor -> more bite.
  float peak = -1.0 / mix(10.0, 5.5, uSharpness);
  vec3 w = amp * peak;
  vec3 sharp = (b + d + f + h) * w + e;
  sharp = sharp / (4.0 * w + 1.0);

  vec3 c = clamp(sharp, 0.0, 1.0);

  // Light grade. Luma uses Rec.709 primaries.
  float luma = dot(c, vec3(0.2126, 0.7152, 0.0722));
  c = mix(vec3(luma), c, uSaturation);
  c = clamp((c - 0.5) * uContrast + 0.5, 0.0, 1.0);

  gl_FragColor = vec4(c, 1.0);
}
