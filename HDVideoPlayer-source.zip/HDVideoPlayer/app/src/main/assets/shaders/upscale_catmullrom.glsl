// Pass 1 - Catmull-Rom bicubic resample.
//
// Bilinear (the default any video player uses) averages 4 neighbours and so
// smears every edge. Catmull-Rom is a 4x4 interpolating cubic: it passes
// exactly through the source samples and has a mild negative lobe, which
// preserves edge acutance instead of blurring it. The 16 taps are folded into
// 9 hardware-bilinear fetches by sampling between texel centres with weights
// chosen so the GPU's own linear filter performs part of the sum.
precision mediump float;

uniform sampler2D uTexSampler;
uniform vec2 uInputSize;   // source video resolution in pixels
varying vec2 vTexCoord;

vec3 catmullRom(vec2 uv) {
  vec2 texSize = uInputSize;
  vec2 samplePos = uv * texSize;
  vec2 texPos1 = floor(samplePos - 0.5) + 0.5;
  vec2 f = samplePos - texPos1;

  // Catmull-Rom basis (tension = 0.5) evaluated per axis.
  vec2 w0 = f * (-0.5 + f * (1.0 - 0.5 * f));
  vec2 w1 = 1.0 + f * f * (-2.5 + 1.5 * f);
  vec2 w2 = f * (0.5 + f * (2.0 - 1.5 * f));
  vec2 w3 = f * f * (-0.5 + 0.5 * f);

  // Fold the middle two taps into one bilinear fetch.
  vec2 w12 = w1 + w2;
  vec2 offset12 = w2 / max(w12, vec2(1e-5));

  vec2 p0 = (texPos1 - 1.0) / texSize;
  vec2 p3 = (texPos1 + 2.0) / texSize;
  vec2 p12 = (texPos1 + offset12) / texSize;

  vec3 c = vec3(0.0);
  c += texture2D(uTexSampler, vec2(p0.x,  p0.y )).rgb * (w0.x  * w0.y );
  c += texture2D(uTexSampler, vec2(p12.x, p0.y )).rgb * (w12.x * w0.y );
  c += texture2D(uTexSampler, vec2(p3.x,  p0.y )).rgb * (w3.x  * w0.y );

  c += texture2D(uTexSampler, vec2(p0.x,  p12.y)).rgb * (w0.x  * w12.y);
  c += texture2D(uTexSampler, vec2(p12.x, p12.y)).rgb * (w12.x * w12.y);
  c += texture2D(uTexSampler, vec2(p3.x,  p12.y)).rgb * (w3.x  * w12.y);

  c += texture2D(uTexSampler, vec2(p0.x,  p3.y )).rgb * (w0.x  * w3.y );
  c += texture2D(uTexSampler, vec2(p12.x, p3.y )).rgb * (w12.x * w3.y );
  c += texture2D(uTexSampler, vec2(p3.x,  p3.y )).rgb * (w3.x  * w3.y );
  return c;
}

void main() {
  gl_FragColor = vec4(clamp(catmullRom(vTexCoord), 0.0, 1.0), 1.0);
}
