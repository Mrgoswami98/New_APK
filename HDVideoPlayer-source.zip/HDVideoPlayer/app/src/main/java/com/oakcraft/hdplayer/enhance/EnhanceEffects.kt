package com.oakcraft.hdplayer.enhance

import android.content.Context
import androidx.media3.common.Effect
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.GlEffect
import androidx.media3.effect.GlShaderProgram

@UnstableApi
private class UpscaleEffect(private val scale: Float) : GlEffect {
    override fun toGlShaderProgram(context: Context, useHdr: Boolean): GlShaderProgram =
        UpscaleShaderProgram(context, useHdr, scale)
}

@UnstableApi
private class SharpenEffect(
    private val sharpness: Float,
    private val saturation: Float,
    private val contrast: Float,
) : GlEffect {
    override fun toGlShaderProgram(context: Context, useHdr: Boolean): GlShaderProgram =
        SharpenShaderProgram(context, useHdr, sharpness, saturation, contrast)
}

/**
 * Builds the effect chain for a profile.
 *
 * [effectiveScale] should already be clamped to the display -- see
 * PlayerActivity.computeScale.
 */
@UnstableApi
fun buildEnhanceChain(profile: EnhanceProfile, effectiveScale: Float): List<Effect> {
    if (profile == EnhanceProfile.OFF) return emptyList()
    val effects = mutableListOf<Effect>()
    if (effectiveScale > 1.001f) effects.add(UpscaleEffect(effectiveScale))
    effects.add(SharpenEffect(profile.sharpness, profile.saturation, profile.contrast))
    return effects
}
