package com.oakcraft.hdplayer.enhance

import android.content.Context
import android.opengl.GLES20
import android.util.Size
import androidx.media3.common.VideoFrameProcessingException
import androidx.media3.common.util.GlProgram
import androidx.media3.common.util.GlUtil
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BaseGlShaderProgram
import kotlin.math.max
import kotlin.math.roundToInt

/** Pass 1: Catmull-Rom bicubic resample to the target resolution. */
@UnstableApi
class UpscaleShaderProgram(
    context: Context,
    useHdr: Boolean,
    private val scale: Float,
) : BaseGlShaderProgram(useHdr, 1) {

    private val program: GlProgram = try {
        GlProgram(context, VERTEX, FRAGMENT)
    } catch (e: Exception) {
        throw VideoFrameProcessingException(e)
    }

    private var inputWidth = 1
    private var inputHeight = 1

    init {
        program.setBufferAttribute(
            "aFramePosition",
            GlUtil.getNormalizedCoordinateBounds(),
            GlUtil.HOMOGENEOUS_COORDINATE_VECTOR_SIZE,
        )
    }

    override fun configure(inputWidth: Int, inputHeight: Int): Size {
        this.inputWidth = max(inputWidth, 1)
        this.inputHeight = max(inputHeight, 1)
        if (scale <= 1.001f) return Size(this.inputWidth, this.inputHeight)
        return Size(
            (this.inputWidth * scale).roundToInt(),
            (this.inputHeight * scale).roundToInt(),
        )
    }

    override fun drawFrame(inputTexId: Int, presentationTimeUs: Long) {
        try {
            program.use()
            program.setSamplerTexIdUniform("uTexSampler", inputTexId, /* texUnitIndex= */ 0)
            program.setFloatsUniform(
                "uInputSize",
                floatArrayOf(inputWidth.toFloat(), inputHeight.toFloat()),
            )
            program.bindAttributesAndUniforms()
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
            GlUtil.checkGlError()
        } catch (e: GlUtil.GlException) {
            throw VideoFrameProcessingException(e, presentationTimeUs)
        }
    }

    override fun release() {
        super.release()
        try {
            program.delete()
        } catch (e: GlUtil.GlException) {
            throw VideoFrameProcessingException(e)
        }
    }

    private companion object {
        const val VERTEX = "shaders/vertex_es2.glsl"
        const val FRAGMENT = "shaders/upscale_catmullrom.glsl"
    }
}
