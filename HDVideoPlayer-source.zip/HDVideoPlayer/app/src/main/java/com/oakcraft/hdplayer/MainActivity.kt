package com.oakcraft.hdplayer

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.ArrayAdapter
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.oakcraft.hdplayer.databinding.ActivityMainBinding
import com.oakcraft.hdplayer.enhance.EnhanceProfile

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val pickVideo = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let { uri ->
                contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
                launchPlayer(uri)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.profileSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            EnhanceProfile.entries.map { it.label },
        )
        binding.profileSpinner.setSelection(EnhanceProfile.BALANCED.ordinal)

        binding.openFileButton.setOnClickListener {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "video/*"
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            pickVideo.launch(intent)
        }

        binding.playUrlButton.setOnClickListener {
            val text = binding.urlInput.text?.toString()?.trim().orEmpty()
            if (text.isNotEmpty()) launchPlayer(Uri.parse(text))
        }

        // Handle "open with" from a file manager or gallery.
        if (intent?.action == Intent.ACTION_VIEW) {
            intent.data?.let { launchPlayer(it) }
        }
    }

    private fun launchPlayer(uri: Uri) {
        startActivity(
            Intent(this, PlayerActivity::class.java).apply {
                data = uri
                putExtra(PlayerActivity.EXTRA_PROFILE, binding.profileSpinner.selectedItemPosition)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        )
    }
}
