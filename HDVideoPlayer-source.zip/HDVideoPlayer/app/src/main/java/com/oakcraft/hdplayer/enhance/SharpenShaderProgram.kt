package com.oakcraft.hdplayer.enhance

import android.content.Context
import android.opengl.GLES20
import android.util.Size
import androidx.media3.common.VideoFrameProcessingException
import androidx.media3.common.util.GlProgram
import androidx.media3.common.util.GlUtil
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BaseGlShaderProgram
import kotlin.math.max

/** Pass 2: contrast-adaptive sharpen plus a light grade. Size-preserving. */
@UnstableApi
class SharpenShaderProgram(
    context: Context,
    useHdr: Boolean,
    private val sharpness: Float,
    private val saturation: Float,
    private val contrast: Float,
) : BaseGlShaderProgram(useHdr, 1) {

    private val program: GlProgram = try {
        GlProgram(context, VERTEX, FRAGMENT)
    } catch (e: Exception) {
        throw VideoFrameProcessingException(e)
    }

    private var width = 1
    private var height = 1

    init {
        program.setBufferAttribute(
            "aFramePosition",
            GlUtil.getNormalizedCoordinateBounds(),
            GlUtil.HOMOGENEOUS_COORDINATE_VECTOR_SIZE,
        )
    }

    override fun configure(inputWidth: Int, inputHeight: Int): Size {
        width = max(inputWidth, 1)
        height = max(inputHeight, 1)
        return Size(width, height)
    }

    override fun drawFrame(inputTexId: Int, presentationTimeUs: Long) {
        try {
            program.use()
            program.setSamplerTexIdUniform("uTexSampler", inputTexId, /* texUnitIndex= */ 0)
            program.setFloatsUniform(
                "uTexelSize",
                floatArrayOf(1f / width, 1f / height),
            )
            program.setFloatUniform("uSharpness", sharpness)
            program.setFloatUniform("uSaturation", saturation)
            program.setFloatUniform("uContrast", contrast)
            program.bindAttributesAndUniforms()
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
            GlUtil.checkGlError()
        } catch (e: GlUtil.GlException) {
            throw VideoFrameProcessingException(e, presentationTimeUs)
        }
    }

    override fun release() {
        super.release()
        try {
            program.delete()
        } catch (e: GlUtil.GlException) {
            throw VideoFrameProcessingException(e)
        }
    }

    private companion object {
        const val VERTEX = "shaders/vertex_es2.glsl"
        const val FRAGMENT = "shaders/sharpen_cas.glsl"
    }
}
