package com.oakcraft.hdplayer.enhance

/**
 * Presets for the enhancement chain.
 *
 * [maxScale] is an upper bound only. The real scale factor is clamped at
 * playback time to the device's panel resolution -- rendering a 4K intermediate
 * on a 1080p screen costs GPU and battery and shows the viewer nothing extra.
 */
enum class EnhanceProfile(
    val label: String,
    val maxScale: Float,
    val sharpness: Float,
    val saturation: Float,
    val contrast: Float,
) {
    OFF("Off (bilinear)", 1.0f, 0.0f, 1.0f, 1.0f),
    BALANCED("Balanced", 2.0f, 0.45f, 1.04f, 1.02f),
    DETAIL("High detail", 2.0f, 0.75f, 1.08f, 1.05f),
    SOFT_SOURCE("Low-quality source", 2.0f, 0.30f, 1.06f, 1.03f);

    companion object {
        fun fromOrdinalSafe(i: Int): EnhanceProfile = entries.getOrElse(i) { BALANCED }
    }
}
