package com.oakcraft.hdplayer

import android.content.Context
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.WindowManager
import androidx.annotation.OptIn
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import com.oakcraft.hdplayer.databinding.ActivityPlayerBinding
import com.oakcraft.hdplayer.enhance.EnhanceProfile
import com.oakcraft.hdplayer.enhance.buildEnhanceChain
import kotlin.math.max
import kotlin.math.min

@OptIn(UnstableApi::class)
class PlayerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPlayerBinding
    private var player: ExoPlayer? = null
    private var profile: EnhanceProfile = EnhanceProfile.BALANCED
    private var appliedForSize: VideoSize? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPlayerBinding.inflate(layoutInflater)
        setContentView(binding.root)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        goFullscreen()

        profile = EnhanceProfile.fromOrdinalSafe(
            intent.getIntExtra(EXTRA_PROFILE, EnhanceProfile.BALANCED.ordinal)
        )
    }

    private fun goFullscreen() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, binding.root).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    private fun initPlayer() {
        val uri = intent?.data ?: run { finish(); return }
        val exo = ExoPlayer.Builder(this).build()
        binding.playerView.player = exo

        exo.addListener(object : Player.Listener {
            override fun onVideoSizeChanged(videoSize: VideoSize) {
                applyEffectsFor(videoSize)
            }

            override fun onPlayerError(error: PlaybackException) {
                Log.e(TAG, "Playback error", error)
                binding.statusText.text = getString(R.string.playback_error, error.errorCodeName)
            }
        })

        exo.setMediaItem(MediaItem.fromUri(uri))
        exo.prepare()
        exo.playWhenReady = true
        player = exo
    }

    /**
     * Applies the enhancement chain once the decoder reports the real source
     * resolution. The scale is derived from the source and the panel, so a 1080p
     * source on a 1080p phone does no pointless resampling.
     */
    private fun applyEffectsFor(videoSize: VideoSize) {
        if (videoSize.width <= 0 || videoSize.height <= 0) return
        if (appliedForSize == videoSize) return
        appliedForSize = videoSize

        val scale = computeScale(this, videoSize.width, videoSize.height, profile)
        player?.setVideoEffects(buildEnhanceChain(profile, scale))

        binding.statusText.text = if (profile == EnhanceProfile.OFF) {
            getString(R.string.status_off, videoSize.width, videoSize.height)
        } else {
            val outW = (videoSize.width * scale).toInt()
            val outH = (videoSize.height * scale).toInt()
            getString(
                R.string.status_on,
                videoSize.width, videoSize.height, outW, outH, profile.label,
            )
        }
    }

    override fun onStart() {
        super.onStart()
        if (player == null) initPlayer()
    }

    override fun onStop() {
        super.onStop()
        binding.playerView.player = null
        player?.release()
        player = null
        appliedForSize = null
    }

    companion object {
        const val EXTRA_PROFILE = "extra_profile"
        private const val TAG = "PlayerActivity"

        /**
         * Clamp the resample factor so the intermediate never exceeds the panel.
         * Upscaling past the display burns GPU and battery for zero visible gain.
         */
        fun computeScale(
            context: Context,
            srcW: Int,
            srcH: Int,
            profile: EnhanceProfile,
        ): Float {
            if (profile == EnhanceProfile.OFF) return 1f
            val metrics = displaySize(context)
            val panelLong = max(metrics.first, metrics.second).toFloat()
            val panelShort = min(metrics.first, metrics.second).toFloat()
            val srcLong = max(srcW, srcH).toFloat()
            val srcShort = min(srcW, srcH).toFloat()
            if (srcLong <= 0f || srcShort <= 0f) return 1f
            val fit = min(panelLong / srcLong, panelShort / srcShort)
            return fit.coerceIn(1f, profile.maxScale)
        }

        private fun displaySize(context: Context): Pair<Int, Int> {
            return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val wm = context.getSystemService(WindowManager::class.java)
                val b = wm.maximumWindowMetrics.bounds
                b.width() to b.height()
            } else {
                val dm = context.resources.displayMetrics
                dm.widthPixels to dm.heightPixels
            }
        }
    }
}
