# HD Video Player

An Android video player that runs every frame through a two-pass GPU
enhancement chain before it reaches the screen.

---

## Read this first: what this app does and does not do

**It does not do neural super-resolution in real time.** Nothing on a phone
does, and any app claiming otherwise is either doing what this app does and
calling it AI, or doing nothing at all. The numbers:

| | Throughput on a 2025 flagship NPU | Needed for video |
|---|---|---|
| Real-ESRGAN / SwinIR class | ~1-5 frames per **second** | 24-60 fps |
| Compact FSRCNN / ESPCN (quantized) | ~15-30 fps at 360p->720p | 24-60 fps |
| This app's shader chain | 500+ fps equivalent | 24-60 fps |

A 10-50x gap is not something you optimize away. Pre-converting the file
instead of enhancing live does not rescue it either: a 10-minute 480p clip
would take several hours of sustained NPU load, thermally throttle the phone
within minutes, and write a file many gigabytes larger than the original.

**Your phone almost certainly cannot display 4K.** Flagship panels are 1080p
or 1440p. Rendering a 4K intermediate to a 1080p panel costs GPU time and
battery and shows the viewer nothing. This app therefore clamps its resample
factor to the actual panel resolution (`PlayerActivity.computeScale`). If you
cast to a 4K TV, raise `EnhanceProfile.maxScale`.

**What it genuinely does:** replaces the bilinear filtering every default
player uses with a far better resampler and an adaptive sharpener. On
360p-720p sources on a 1080p+ panel the difference is clearly visible -
edges stay crisp instead of smearing, and text and faces hold up. That is a
real, honest quality improvement. It is not 4K, and the UI does not claim it is.

### The two passes

1. **Catmull-Rom bicubic resample** (`upscale_catmullrom.glsl`). A 4x4
   interpolating cubic with a mild negative lobe, folded into 9 hardware
   bilinear fetches. Bilinear averages 4 neighbours and smears every edge;
   Catmull-Rom passes exactly through the source samples and preserves edge
   acutance.

2. **Contrast-adaptive sharpening** (`sharpen_cas.glsl`). A fixed unsharp mask
   is actively harmful on low-bitrate video - it amplifies blocking and
   mosquito noise as eagerly as detail. This measures local headroom from a
   5-tap cross and scales sharpening by how much room the neighbourhood has
   before clipping, so flat and noisy regions get almost none and real edges
   get the most. Then an optional light saturation/contrast grade.

Both run as `GlEffect`s on the Media3 frame-processing pipeline, so they sit
between the hardware decoder and the display surface with no CPU copy.

---

## Building the APK

This project was authored without an Android SDK present, so the Gradle
wrapper JAR is not included. Either path works:

**Android Studio (easiest)**
1. Open the `HDVideoPlayer` folder. Studio will offer to generate the wrapper
   and sync - accept.
2. `Build > Generate App Bundles or APKs > Generate APKs`.
3. The file lands in `app/build/outputs/apk/debug/`.

**Command line**
```bash
cd HDVideoPlayer
gradle wrapper --gradle-version 8.9   # one time, needs network
./gradlew assembleRelease
```
Output: `app/build/outputs/apk/release/app-release.apk`

### Signing
`build.gradle.kts` currently signs release builds with the **debug** key so
the build succeeds out of the box. That APK installs and runs fine for your
own use, but Play Store will reject it. For a real release:

```bash
keytool -genkey -v -keystore release.jks -keyalg RSA \
  -keysize 2048 -validity 10000 -alias hdplayer
```
then add a proper `signingConfigs.release` block and point the release build
type at it.

---

## If you want actual AI upscaling: the realistic path

Treat it as an **export job**, not playback. The architecture:

1. Add `com.google.ai.edge.litert:litert:1.x` and
   `litert-gpu` / `litert-support`.
2. Ship a *compact* super-resolution model - FSRCNN or ESPCN at around 20-60k
   parameters, int8-quantized. Not Real-ESRGAN; it will not fit the thermal
   budget.
3. Decode with `MediaCodec` to an `ImageReader`, run the model per frame with
   the GPU or NNAPI delegate, re-encode with `MediaCodec` + `MediaMuxer`.
4. Run it in a `ForegroundService` with a progress notification, and require
   the charger to be connected.

Honest expectation: roughly **10-40 minutes of processing per minute of
480p video**, phone hot throughout. The quality gain over the shader chain in
this app is real but modest for most content - noticeably better on animation
and clean low-res sources, marginal on noisy compressed video, where the model
tends to sharpen the compression artifacts along with the picture.

If quality genuinely matters more than convenience, do the upscale on a
desktop GPU or a rented cloud GPU and sync the result to the phone. That is
what every serious workflow actually does.

---

## Project layout

```
app/src/main/
  assets/shaders/          the three GLSL files - all the image quality lives here
  java/.../enhance/        Media3 GlEffect wrappers and the profile presets
  java/.../MainActivity    picker: local file or URL, profile selection
  java/.../PlayerActivity  ExoPlayer, fullscreen, display-aware scale clamp
```

Tuning: `EnhanceConfig.kt` holds the presets. `sharpness` above ~0.8 starts
showing halos on compressed sources.
